<!DOCTYPE html>
<html>

<head>
    <title>Beranda</title>
    <style>
    {
        box-sizing: padding-box;
    }
    body{
        font-family: 'Poppins';
        background: linear-gradient(to right bottom, #ffe4f3, #ffbeef);
        height: 100vh;
        display: fill;
        align-items: center;
        justify-content: center;
        color: #44001a;
        }
    .container {
        max-width: 550px;
        margin: 0 auto;
        padding: 30px;
        background-color: #ffeef2;
        border-radius: 50px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        margin-top: 200px;
    }
    h1 {
        color: #44001a;
        text-align: center;
        margin-bottom: 10px;
    }
    table {
        width: 50%;
    }
    th,
    td {
        padding: 10px;
        text-align: left;
    }
    th {
        width: 30%;
    }
    .btn-container {
        display: flex;
        justify-content: center;
    }
    button {
        position: relative;
        display: inline-block;
        cursor: pointer;
        outline: none;
        border: 0;
        vertical-align: middle;
        text-decoration: none;
        font-family: 'Poppins';
        font-size: 15px;
    }

    button.learn-more {
        font-weight: 600;
        color: #382b22;
        text-transform: uppercase;
        padding: 1.25em 2em;
        background: #fff0f0;
        border: 2px solid #b18597;
        border-radius: 0.75em;
        -webkit-transform-style: preserve-3d;
        transform-style: preserve-3d;
        -webkit-transition: background 150ms cubic-bezier(0, 0, 0.58, 1), -webkit-transform 150ms cubic-bezier(0, 0, 0.58, 1);
        transition: transform 150ms cubic-bezier(0, 0, 0.58, 1), background 150ms cubic-bezier(0, 0, 0.58, 1), -webkit-transform 150ms cubic-bezier(0, 0, 0.58, 1);
    }

    button.learn-more::before {
        position: absolute;
        content: '';
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: #f9c4d2;
        border-radius: inherit;
        -webkit-box-shadow: 0 0 0 2px #b18597, 0 0.625em 0 0 #ffe3e2;
        box-shadow: 0 0 0 2px #b18597, 0 0.625em 0 0 #ffe3e2;
        -webkit-transform: translate3d(0, 0.75em, -1em);
        transform: translate3d(0, 0.75em, -1em);
        transition: transform 150ms cubic-bezier(0, 0, 0.58, 1), box-shadow 150ms cubic-bezier(0, 0, 0.58, 1), -webkit-transform 150ms cubic-bezier(0, 0, 0.58, 1), -webkit-box-shadow 150ms cubic-bezier(0, 0, 0.58, 1);
    }

    button.learn-more:hover {
        background: #ffe9e9;
        -webkit-transform: translate(0, 0.25em);
        transform: translate(0, 0.25em);
    }

    button.learn-more:hover::before {
        -webkit-box-shadow: 0 0 0 2px #b18597, 0 0.5em 0 0 #ffe3e2;
        box-shadow: 0 0 0 2px #b18597, 0 0.5em 0 0 #ffe3e2;
        -webkit-transform: translate3d(0, 0.5em, -1em);
        transform: translate3d(0, 0.5em, -1em);
    }

    button.learn-more:active {
        background: #ffe9e9;
        -webkit-transform: translate(0em, 0.75em);
        transform: translate(0em, 0.75em);
    }

    button.learn-more:active::before {
        -webkit-box-shadow: 0 0 0 2px #b18597, 0 0 #ffe3e2;
        box-shadow: 0 0 0 2px #b18597, 0 0 #ffe3e2;
        -webkit-transform: translate3d(0, 0, -1em);
        transform: translate3d(0, 0, -1em);
    }

    </style>

</head>

<body>
    <div class="container">
        <h1>Profile</h1>
        <table>
            <tr>
                <th>Nama</th>
                <td>
                    <?= $nama ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td>
                    <?= $nim ?>
                </td>
            </tr>
        </table>
        <div class="btn-container">
            <form action="/home/profil">
            <button class="learn-more">
            Biodata
            </button>
            </form>
        </div>
    </div>
</body>
</html>