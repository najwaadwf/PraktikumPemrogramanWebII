<?php

namespace App\Controllers;

use App\Models\ProfilModel;

class Home extends BaseController
{
    public function beranda()
    {
        $mhs = new ProfilModel();
        return view('beranda', [
            "nama" => $mhs->getNama(),
            "nim" => $mhs->getNim()
        ]);
    }

    public function profil()
    {
        $mhs = new ProfilModel();
        return view('profil', [
            "nama" => $mhs->getNama(),
            "nim" => $mhs->getNim(),
            "citacita" => $mhs->getCitaCita(),
            "skill" => $mhs->getSkill(),
            "prodi" => $mhs->getProdi(),
            "motivasi" => $mhs->getMotivasi(),
            "hobi" => $mhs->getHobi(),
            "img" => $mhs->getImg()
        ]);
    }
}