<?php

namespace App\Models;

use CodeIgniter\Model;

class ProfilModel extends Model
{
    protected $nama = "Najwa Dwi Febrianti";
    protected $nim = "2110817220014";
    protected $prodi = "Teknologi Informasi";
    protected $citacita = "Data Analyst";
    protected $hobi = "Find something new";
    protected $skill = "Desain";
    protected $motivasi = "Just always do what you want, if it in the right way";
    protected $img = "img.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getCitaCita()
    {
        return $this->citacita;
    }
    public function getHobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getMotivasi()
    {
        return $this->motivasi;
    }
    public function getImg()
    {
        return $this->img;
    }
}